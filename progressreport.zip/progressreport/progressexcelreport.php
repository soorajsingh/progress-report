<?php
require('../../config.php');
require_once("{$CFG->libdir}/completionlib.php");
require_once("$CFG->libdir/phpexcel/PHPExcel.php");

global $DB,$CFG;
require_login();
$title = 'Progress Report';

$sql_filter="SELECT * FROM {user} where suspended=0 and deleted=0 and id>2 ";

$courses=$DB->get_records('course'); 
$ccount=$DB->count_records('course'); 
$users=$DB->get_records_sql($sql_filter); 



$objPHPExcel = new PHPExcel;
	// set default font
	$objPHPExcel->getDefaultStyle()->getFont()->setName('Arial');
	// set default font size
	$objPHPExcel->getDefaultStyle()->getFont()->setSize(10);
	// create the writer
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel2007");
	// currency format, € with < 0 being in red color
	$currencyFormat = '#,#0.## \€;[Red]-#,#0.## \€';
	// number format, with thousands separator and two decimal points.
	$numberFormat = '#,#0.##;[Red]-#,#0.##';
	
	//$a="A1:C2";


	$next="H";
	for($ic=0;$ic<$ccount;$ic++){
		$next++;
		$next++;
		$next++;
	}
	$next++;
	$a="A1:$next"."2";
		$objPHPExcel->getActiveSheet()->getStyle($a)->getFont()->setBold(true)->setSize(20)->getColor()->setRGB('FFFFFF');
				$objPHPExcel->getActiveSheet()->mergeCells($a);
				$objPHPExcel->getActiveSheet()->getCell('A1')->setValue('Progress Report');
				$objPHPExcel->getActiveSheet()->getStyle($a)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
				$objPHPExcel->getActiveSheet()->getStyle($a)->getFill()                                                               ->setFillType(PHPExcel_Style_Fill::FILL_SOLID) ->getStartColor()
				->setARGB('149dc6');
				
	$b="A3:$next"."3";		
	$objPHPExcel->getActiveSheet()->getStyle($b)->getFont()->setBold(true)->setSize(11);
	$objPHPExcel->getActiveSheet()->setCellValue('A3','Sr No');
	// $style_for_a = "A";
	// $objPHPExcel->getActiveSheet()->getStyle($style_for_a)->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
	// $objPHPExcel->getActiveSheet()->getStyle($a)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID) ->getStartColor()->setARGB('c2d69b');
	$objPHPExcel->getActiveSheet()->setCellValue('B3','Student Name');
	$objPHPExcel->getActiveSheet()->setCellValue('C3','Email');
	$objPHPExcel->getActiveSheet()->setCellValue('D3','Enrollment Date');
	$objPHPExcel->getActiveSheet()->setCellValue('E3','First login');
	$objPHPExcel->getActiveSheet()->setCellValue('F3','Last Login');
	$objPHPExcel->getActiveSheet()->setCellValue('G3','Batch');
	$clm=3;
	$head="H";
	for($ic=1;$ic<=$ccount;$ic++){
		$objPHPExcel->getActiveSheet()->setCellValue($head.$clm,'Course '.$ic);
		$head++;
		$objPHPExcel->getActiveSheet()->setCellValue($head.$clm,'Progress '.$ic);
		$head++;
		$objPHPExcel->getActiveSheet()->setCellValue($head.$clm,'Completion Date '.$ic);
		$head++;
	}
	$objPHPExcel->getActiveSheet()->setCellValue($head.$clm,'Overall Progress');
	$head++;
	$objPHPExcel->getActiveSheet()->setCellValue($head.$clm,'Overall Completion Date');

	
    if(count($users)>0)
	{
		$count = 1;
		$rowCount = 4;
		foreach ($users as $user) 
		{
			//print_object($user);
			$userid=$user->id;
			$row=array();
			$username=ucfirst(strtolower(fullname($user)));
			$email=strtolower($user->email);
			$firstaccess="Not Yet";
			if($user->firstaccess){
				$firstaccess=date('d m Y',$user->firstaccess);
			}
			$lastaccess="Not Yet";
			if($user->lastaccess){
				$lastaccess=date('d m Y',$user->lastlogin);
			}
			
			$enrollment=date('d m Y',$user->timecreated);
			
			$column='A';
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,$count);
			$column++;	
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$username);
			$column++;		
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$email);
			$column++;	
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$enrollment);
			$column++;
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$firstaccess);
			$column++;		
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$lastaccess);
			$column++;	
			
			
			$inc1=0;
			$totalsum=0;
			$allcompletion=0;
			$groupname="Not Assigned";
			foreach($courses as $course)
			{
				$inc1++;
				if($inc1==1)
				{
						$group=$DB->get_record_sql("select g.name from {groups} g join {groups_members} gm on g.id=gm.groupid where gm.userid=$userid and g.courseid=".$course->id);
						if($group)
						{
							$groupname=$group->name;
						}
						$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$groupname);
						$column++;	
				}
				$coursename=$course->fullname;
				$cinfo = new completion_info($course);
				$coursecontext=context_course::instance($course->id);
				$completiondate="Not Enrolled";
				$percent="Not Enrolled";
				if (is_enrolled($coursecontext, $user->id))
				{
					
					if($result=get_course_percentage($course,$user->id))
					{
						$percent=$result."%";
						$totalsum=$totalsum+$result;
					}else{
						$percent='0%';
					}
					
					$iscomplete = $cinfo->is_course_complete($user->id);
					if($iscomplete){
						$timecompleted=$DB->get_field('course_completions','timecompleted',array('userid'=>$userid,'course'=>$course->id));
						$completiondate=date('d m Y',$timecompleted);
						if($allcompletion<$timecompleted){
							$allcompletion=$timecompleted;
						}
					}else{
						$completiondate="In Progress";
					}
					
				}
					
				
			
				$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$coursename);
				$column++;	
				$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$percent);
				$column++;	
				$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$completiondate);
				$column++;
				
			}
			

			if($inc1 && $totalsum){
				$overallprogress=$totalsum/$inc1."%";
			}else{
				$overallprogress="0%";
			}
			if($allcompletion)
			{
				$overallcompletion=date('d m Y',$allcompletion);
			}else{
				$overallcompletion="Not Enrolled";
			}
		
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$overallprogress);
			$column++;	
			$objPHPExcel->getActiveSheet()->setCellValue($column.$rowCount,@$overallcompletion);
			$column++;
			
			$rowCount++;
			$count++;
		}
	}
	$char='A';
	for($i=0; $i<26; $i++)
	{
		$objPHPExcel->getActiveSheet()->getColumnDimension($char)->setAutoSize(true);
		$char++;
	}	

$save_name='Excelreport.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename='.$save_name);
header('Cache-Control: max-age=0');
$objWriter->save('php://output');




function get_course_percentage($course, $userid = 0) {
        global $USER;

        // Make sure we continue with a valid userid.
        if (empty($userid)) {
            $userid = $USER->id;
        }

        $completion = new completion_info($course);

        // First, let's make sure completion is enabled.
        if (!$completion->is_enabled()) {
            return null;
        }

        // Before we check how many modules have been completed see if the course has.
        if ($completion->is_course_complete($userid)) {
            return 100;
        }

        // Get the number of modules that support completion.
        $modules = $completion->get_activities();
        $count = count($modules);
        if (!$count) {
            return null;
        }

        // Get the number of modules that have been completed.
        $completed = 0;
        foreach ($modules as $module) {
            $data = $completion->get_data($module, false, $userid);
            $completed += $data->completionstate == COMPLETION_INCOMPLETE ? 0 : 1;
        }

        return ($completed / $count) * 100;
    }
?>
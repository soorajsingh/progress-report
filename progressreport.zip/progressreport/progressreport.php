<?php

require('../../config.php');
require_once("{$CFG->libdir}/completionlib.php");
global $DB,$CFG;
require_login();
$title = 'Progress Report';
$PAGE->set_context(context_system::instance());
$PAGE->set_pagelayout('standard');
$PAGE->set_title($title);
$PAGE->set_heading('Progress Report');
$page=optional_param('page',0,PARAM_INT);
$PAGE->set_url('/local/progressreport/progressreport.php');

$perpage = optional_param('perpage', 10, PARAM_INT);
$paging = ($page * $perpage);
echo'<link rel="stylesheet" href="style.css">';
//echo'<link rel="stylesheet" href="style.css">';
echo $OUTPUT->header();


$sql_filter="SELECT * FROM {user} where suspended=0 and deleted=0 and id>2 ";

$sec=$DB->get_records_sql($sql_filter); 
$val=count($sec);
echo'<div class="clearfix"></div>';

$sql_filter .=" limit $paging,$perpage";

$users=$DB->get_records_sql($sql_filter); 
$table = new html_table();
$table->attributes['class'] = 'table table-striped table-hover table-custome-new';
$table->head =array('Sr No.','Student Name','Email','Enrollment Date','First Access','Last Login','Batch');

$courses=$DB->get_records('course');
$inc=1;
foreach($courses as $course)
{
	$table->head[]="Course ".$inc;
	$table->head[]="Progress ".$inc;
	$table->head[]="Completion Date ".$inc;
	$inc++;
}
$table->head[]="Overall Progress";
$table->head[]="Overall Completion Date";
$value=0;
$value=$page*$perpage;
foreach($users as $user) 
		{
			//print_object($user);
			$userid=$user->id;
			$row=array();
			$username=ucfirst(strtolower(fullname($user)));
			$email=strtolower($user->email);
			$firstaccess="Not Yet";
			if($user->firstaccess){
				$firstaccess=date('d m Y',$user->firstaccess);
			}
			$lastaccess="Not Yet";
			if($user->lastaccess){
				$lastaccess=date('d m Y',$user->lastlogin);
			}
			
			$enrollment=date('d m Y',$user->timecreated);
			
			$row[]=$value;
			$row[]=$username;	
			$row[]=$email;
			$row[]=$enrollment;
			$row[]=$firstaccess;		
			$row[]=$lastaccess;	
			
			
			$inc1=0;
			$totalsum=0;
			$allcompletion=0;
			$groupname="Not Assigned";
			foreach($courses as $course)
			{
				$inc1++;
				if($inc1==1)
				{
						$group=$DB->get_record_sql("select g.name from {groups} g join {groups_members} gm on g.id=gm.groupid where gm.userid=$userid and g.courseid=".$course->id);
						if($group)
						{
							$groupname=$group->name;
						}
						$row[]=$groupname;	
				}
				$coursename=$course->fullname;
				$cinfo = new completion_info($course);
				$coursecontext=context_course::instance($course->id);
				$completiondate="Not Enrolled";
				$percent="Not Enrolled";
				if (is_enrolled($coursecontext, $user->id))
				{
					
					if($result=get_course_percentage($course,$user->id))
					{
						$percent=$result."%";
						$totalsum=$totalsum+$result;
					}else{
						$percent='0%';
					}
					
					$iscomplete = $cinfo->is_course_complete($user->id);
					if($iscomplete){
						$timecompleted=$DB->get_field('course_completions','timecompleted',array('userid'=>$userid,'course'=>$course->id));
						$completiondate=date('d m Y',$timecompleted);
						if($allcompletion<$timecompleted){
							$allcompletion=$timecompleted;
						}
					}else{
						$completiondate="In Progress";
					}
					
				}
					
				
			
				$row[]=$coursename;
				$row[]=$percent;
				$row[]=$completiondate;
				
			}
			

			if($inc1 && $totalsum){
				$overallprogress=$totalsum/$inc1."%";
			}else{
				$overallprogress="0%";
			}
			if($allcompletion)
			{
				$overallcompletion=date('d m Y',$allcompletion);
			}else{
				$overallcompletion="Not Enrolled";
			}
		
			$row[]=$overallprogress;	
			$row[]=$overallcompletion;
			$value++;
		//print_object($row);
	$table->data[]=$row;
}	


echo '<div class="table-responsive">';
echo html_writer::link(new moodle_url($CFG->wwwroot.'/local/progressreport/progressexcelreport.php'),'Excell Report',array('class'=>'btn btn-success pull-left'));
echo'<div class="clearfix"></div>';
echo html_writer::table($table);
echo'</div>';

echo'<div class="clearfix"></div>';


$totalrecord=$val;
$baseurl=new moodle_url($CFG->wwwroot.'/local/progressreport/progressreport.php',array('perpage'=>$perpage,'page'=>$page));
echo $OUTPUT->paging_bar($totalrecord, $page, $perpage,$baseurl);

// echo html_writer::tag('div', "", array('class'=>'blah'));
echo $OUTPUT->footer();



function get_course_percentage($course, $userid = 0) {
        global $USER;

        // Make sure we continue with a valid userid.
        if (empty($userid)) {
            $userid = $USER->id;
        }

        $completion = new \completion_info($course);

        // First, let's make sure completion is enabled.
        if (!$completion->is_enabled()) {
            return null;
        }

        // Before we check how many modules have been completed see if the course has.
        if ($completion->is_course_complete($userid)) {
            return 100;
        }

        // Get the number of modules that support completion.
        $modules = $completion->get_activities();
        $count = count($modules);
        if (!$count) {
            return null;
        }

        // Get the number of modules that have been completed.
        $completed = 0;
        foreach ($modules as $module) {
            $data = $completion->get_data($module, false, $userid);
            $completed += $data->completionstate == COMPLETION_INCOMPLETE ? 0 : 1;
        }

        return ($completed / $count) * 100;
    }
?>
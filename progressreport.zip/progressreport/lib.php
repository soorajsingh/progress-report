<?php



//find manager of user




function local_progressreport_extend_navigation(global_navigation $navigation)
	{
    	
	    global $CFG, $PAGE, $USER,$DB;
		$kng1=$navigation->add('Progress Report ');
        $kng1->add( 'Progress Report', new moodle_url($CFG->wwwroot . '/local/progressreport/progressreport.php'));
    }
	

?>
